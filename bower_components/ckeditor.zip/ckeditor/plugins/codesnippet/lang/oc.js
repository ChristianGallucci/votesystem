﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","oc",{button:"Inserir un extrait de còdi",codeContents:"Còdi",emptySnippetError:"Un extrait de còdi pòt pas èsser void.",language:"Lenga",title:"Extrait de còdi",pathName:"extrait de còdi"});